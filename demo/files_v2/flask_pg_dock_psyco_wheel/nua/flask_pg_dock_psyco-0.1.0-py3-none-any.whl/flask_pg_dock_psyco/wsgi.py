from .flask_pg_dock_psyco import app

if __name__ == "__main__":
    app.run()
