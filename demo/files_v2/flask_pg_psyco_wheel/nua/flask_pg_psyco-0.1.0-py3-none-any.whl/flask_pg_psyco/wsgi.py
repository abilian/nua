from .flask_pg_psyco import app

if __name__ == "__main__":
    app.run()
