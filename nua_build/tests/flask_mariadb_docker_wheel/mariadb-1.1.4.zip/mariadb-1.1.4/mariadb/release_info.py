__author__ = 'Georg Richter'
__version__ = '1.1.4'
__version_info__ = (1, 1, 4, '', 0)
