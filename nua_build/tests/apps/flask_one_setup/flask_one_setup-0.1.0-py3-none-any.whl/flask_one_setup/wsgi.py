from .flask_one_setup import app

if __name__ == "__main__":
    app.run()
